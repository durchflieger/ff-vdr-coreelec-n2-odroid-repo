#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later

VDR_ROOT_DIR=/storage/.config/vdr

[ -f ${VDR_ROOT_DIR}/vdr-frontend.sh ] && /bin/sh ${VDR_ROOT_DIR}/vdr-frontend.sh $*

if [ "$1" == "start" ] ; then
  cmd="plug softhdodroid atta\nremo on\nquit"
else
  cmd="remo off\nplug softhdodroid deta\nquit"
fi
echo -e "$cmd" | nc -w 20 localhost 6419
