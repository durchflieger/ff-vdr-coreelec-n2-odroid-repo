#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later

# Here you can add commands which will be executed on vdr frontend service start /stop

#case "$1" in
#start)
#	echo "720p50hz" > /sys/class/display/mode
#	;;
#stop)
#	;;
#esac
