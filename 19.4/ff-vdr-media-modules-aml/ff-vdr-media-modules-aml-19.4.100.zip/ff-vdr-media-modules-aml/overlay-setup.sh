#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later

FF_VDR_ADDON_NAME="ff-vdr-media-modules-aml"

echo "${FF_VDR_ADDON_NAME}/overlay-setup.sh started"

. /etc/profile

oe_setup_addon ${FF_VDR_ADDON_NAME}

KERNEL_VERSION=`uname -r`
DRIVER_DIR=/lib/modules/${KERNEL_VERSION}/media_modules-aml

ln -sf $ADDON_DIR/*.ko $DRIVER_DIR

echo "${FF_VDR_ADDON_NAME}/overlay-setup.sh done"
